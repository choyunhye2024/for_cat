package com.for_;

public class Cat {

	String name;
	int age;
	
	//생성자 함수를 자동으로 불러오는 법: 오른쪽마우스 - source - Generate Constructor using Fields - Generate

	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

}
